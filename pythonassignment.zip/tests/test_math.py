"""unit test case for square root"""

import unittest
from src.sq_calc import sample


class TestSquareRoot(unittest.TestCase):
    """ test case"""
    def test_square_root_positive(self):
        """test case for positive value"""
        self.assertEqual(sample.square_root(4), 2.0)

    def test_square_root_negative(self):
        """test case for negative value"""
        self.assertEqual(sample.square_root(-8), complex(1.7319121124709868e-16+2.8284271247461903j))

    def test_square_root_string(self):
        """test case for string"""
        self.assertEqual(sample.square_root("a"), "typeerror")


if __name__ == '__main__':
    unittest.main()
