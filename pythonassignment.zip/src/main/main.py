from src.sq_calc import sample
import sys


def main():
    x= (sys.argv[1])
    res = sample.square_root(x)
    print(res)
