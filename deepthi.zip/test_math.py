"""unit test case for square root"""

import unittest
import sample


class TestSquareRoot(unittest.TestCase):
    """ test case"""
    def test_square_root_positive(self):
        """test case for positive value"""
        result = sample.square_root(4)
        self.assertEqual(result, 2.0)

    def test_square_root_negative(self):
        """test case for negative value"""
        result = sample.square_root(-1)
        self.assertEqual(result, "ValueError")


if __name__ == '__main__':
    unittest.main()
