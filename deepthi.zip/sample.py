"""Program for calculating square root"""


def square_root(x_value):
    """function for calculating square root"""
    try:
        if x_value > 0:
            print x_value**0.5
            return x_value**0.5
        else:
            raise ValueError
    except ValueError:
        print "enter positive value"
        return "ValueError"
